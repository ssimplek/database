<?php require('includes/config.php'); ?>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Online Pos System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" />
<link href="registration/demo.css" rel="stylesheet" type="text/css" />
<link href="registration/style.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<script src="js/bootstrap.min.js"></script>