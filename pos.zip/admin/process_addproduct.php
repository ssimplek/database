<?php
require('includes/config.php');

	if(!empty($_POST))
	{
		$msg=array();
		if(empty($_POST['name']) || empty($_POST['description']) || empty($_POST['publisher'])|| empty($_POST['count']) || empty($_POST['price']))
		{
			$msg[]="Please full fill all requirement";
		}
		
		if(!(is_numeric($_POST['price'])))
		{
			$msg[]="Price must be in Numeric  Format...";
		}
		
		if(!(is_numeric($_POST['count'])))
		{
			$msg[]="Page must be in Numeric  Format...";
		}
		
		if(empty($_FILES['img']['name']))
		$msg[] = "Please provide a file";
	
		if($_FILES['img']['error']>0)
		$msg[] = "Error uploading file";
		
				
		if(!(strtoupper(substr($_FILES['img']['name'],-4))==".JPG" || strtoupper(substr($_FILES['img']['name'],-5))==".JPEG"|| strtoupper(substr($_FILES['img']['name'],-4))==".GIF"))
			$msg[] = "wrong file  type";
			
		if(file_exists("../upload_image/".$_FILES['img']['name']))
			$msg[] = "File already uploaded. Please do not updated with same name";
		
		
		if(!empty($msg))
		{
			echo '<b>Error:-</b><br>';
			
			foreach($msg as $k)
			{
				echo '<li>'.$k;
			}
		}
		else
		{
			move_uploaded_file($_FILES['img']['tmp_name'],"../upload_image/".$_FILES['img']['name']);
			$p_img = "upload_image/".$_FILES['img']['name'];	
			
		
			$p_nm=$_POST['name'];
			$p_cat=$_POST['cat'];
			$p_desc=$_POST['description'];
			$p_publisher=$_POST['publisher'];			
			$p_count=$_POST['count'];
			$p_price=$_POST['price'];
			
			
			$query="insert into product(p_nm,p_subcat,p_desc,p_publisher,p_count,p_price,p_img)
			values('$p_nm','$p_cat','$p_desc','$p_publisher',$p_count,$p_price,'$p_img')";
			
			mysqli_query($conn,$query) or die($query."Can't Connect to Query...");
			header("location:addproduct.php");
		
		}
	}
	else
	{
		header("location:index.php");
	}
?>
	
	