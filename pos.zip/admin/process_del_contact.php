<?php
	$id = $_GET['sid'];
	require('includes/config.php');
	$sql = "DELETE FROM contact WHERE con_id = $id";
	mysqli_query($conn, $sql);
	header("location:contact.php");
?>