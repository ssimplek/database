<?php
	$id = $_GET['sid'];
	require('includes/config.php');
	$sql = "DELETE FROM product WHERE p_id = $id";
	mysqli_query($conn, $sql);
	header("location:all_product.php");
?>