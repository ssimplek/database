<div id="footer-wrap">
	<p id="legal">Create by Kim Neung-Hwan & Choi Hye-min </a></p>
	</div>