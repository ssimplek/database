<?php 
$conn=mysqli_connect("localhost","root","","dbsystem")or die("Can't Connect...");

?>